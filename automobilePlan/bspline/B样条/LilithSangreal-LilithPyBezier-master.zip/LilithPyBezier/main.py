from LilithPyBezier.LilithPyBezier import LPBezier
from PIL import Image

if __name__ == '__main__':
    newCanvas = LPBezier(6, 6) # which mean 6 * 100 px
    newCanvas.show()
